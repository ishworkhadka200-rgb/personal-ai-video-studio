PERSONAL AI VIDEO STUDIO — STARTER BUILD

Included:
- index.html: mobile-friendly UI for Text-to-Video and Image-to-Video
- duration options: 5, 10, 15, 20, 30 seconds
- aspect ratio options, including 9:16 portrait
- sound preference field
- image upload preview for Image-to-Video

IMPORTANT LIMITATION
This is the interface/starter build only. It does NOT generate video yet because no reliable, free video-generation backend has been connected. A frontend alone cannot run a large video model. Public demos may have queues and usage limits; APIs may require payment. Do not put private API tokens in index.html.

NEXT STEP
Deploy or open index.html to review the interface, then connect a real model through a secure backend after verifying that the model endpoint is accessible and its free-use terms/limits meet the user's requirements. Do not claim unlimited/free generation unless verified.
